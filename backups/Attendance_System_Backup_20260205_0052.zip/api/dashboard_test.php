<?php
// api/dashboard_test.php
date_default_timezone_set("Asia/Manila");
// Intentionally not setting JSON header to see errors
require_once '../includes/db.php';

echo "DEBUG INFO FROM NEW FILE:\n";
echo "DB Path: " . $database . "\n";
echo "Today: " . date('Y-m-d') . "\n";

try {
    $today = date('Y-m-d');
    $stmt = $pdo->prepare("SELECT status, COUNT(*) as count FROM attendance WHERE date = ? GROUP BY status");
    $stmt->execute([$today]);
    $stats = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    
    echo "Stats:\n";
    print_r($stats);
    
    // Also check total count again
    $total = $pdo->query("SELECT COUNT(*) FROM attendance")->fetchColumn();
    echo "\nTotal DB Records: $total\n";

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
