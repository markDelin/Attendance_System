<?php
// database/fix_duplicates.php
date_default_timezone_set('Asia/Manila');
require __DIR__ . '/../includes/db.php';

// Map of OLD_ID => NEW_ID (Source of data)
// We want to KEEP Old ID (for student links) but GET data from New ID
$mergeMap = [
    6 => 18, // Art & Humanities
    4 => 16, // Ethics
    8 => 14, // General Physics
    1 => 13, // Information Management
    2 => 10, // IT Infrastructure
    5 => 17, // Math
    3 => 11, // Org & Mgmt
    9 => 15, // Social Science
    7 => 12  // Team Sports
];

echo "Starting Merge Process...\n";

try {
    $pdo->beginTransaction();

    foreach ($mergeMap as $oldId => $newId) {
        // 1. Fetch New Data
        $stmt = $pdo->prepare("SELECT * FROM subjects WHERE id = ?");
        $stmt->execute([$newId]);
        $newSub = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$newSub) {
            echo "Skipping pair $oldId <- $newId (New subject not found)\n";
            continue;
        }

        echo "Merging {$newSub['name']} ($newId) into $oldId ...\n";

        // 2. Update Old Subject with New Details (including Name to match style)
        // We preserve the PRIMARY KEY ($oldId)
        $updateSql = "UPDATE subjects SET 
                        name = ?, 
                        code = ?, 
                        room = ?, 
                        lecturer = ?, 
                        semester = ? 
                      WHERE id = ?";
        $pdo->prepare($updateSql)->execute([
            $newSub['name'], 
            $newSub['code'], 
            $newSub['room'], 
            $newSub['lecturer'], 
            $newSub['semester'], 
            $oldId
        ]);

        // 3. Move Schedules
        // Any schedule pointing to New ID should point to Old ID
        // First delete any existing schedules for Old ID to avoid conflicts/mess (assuming New ID has the correct schedule)
        $pdo->prepare("DELETE FROM schedules WHERE subject_id = ?")->execute([$oldId]);
        
        $pdo->prepare("UPDATE schedules SET subject_id = ? WHERE subject_id = ?")->execute([$oldId, $newId]);

        // 4. Delete New Subject
        $pdo->prepare("DELETE FROM subjects WHERE id = ?")->execute([$newId]);
        
        echo " > Done.\n";
    }

    $pdo->commit();
    echo "Merge Complete!\n";

} catch (Exception $e) {
    $pdo->rollBack();
    echo "Error: " . $e->getMessage();
}
