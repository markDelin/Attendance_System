<?php
// database/seed_schedule.php
require_once __DIR__ . '/../includes/db.php';

$semester = "2nd Sem 2025-2026"; // Default/Assumed

// 1. Define the Schedule Data
$scheduleData = [
    // Mon & Tue
    'IT INFRASTRUCTURE AND NETWORK TECHNOLOGY' => [
        'code' => 'IS 222', 'room' => 'COLLEGE COMLAB', 'lecturer' => 'MAYO, RODERICK',
        'times' => [['days' => ['Monday', 'Tuesday'], 'start' => '07:30', 'end' => '09:00']]
    ],
    'ORGANIZATION AND MANAGEMENT CONCEPTS' => [
        'code' => 'IS 223', 'room' => 'COLLEGE COMLAB', 'lecturer' => 'MAYO, RODERICK',
        'times' => [['days' => ['Monday', 'Tuesday'], 'start' => '09:00', 'end' => '10:30']]
    ],
    'TEAM SPORTS' => [
        'code' => 'P.E.4', 'room' => 'TBA', 'lecturer' => 'OBRIQUE, SZLYX',
        'times' => [['days' => ['Monday', 'Tuesday'], 'start' => '13:00', 'end' => '14:00']]
    ],
    'INFORMATION MANAGEMENT' => [
        'code' => 'IS 221', 'room' => 'TBA', 'lecturer' => 'IYO, KHISTA',
        'times' => [['days' => ['Monday', 'Tuesday'], 'start' => '14:00', 'end' => '15:30']]
    ],
    'GENERAL PHYSICS' => [
        'code' => 'PHY', 'room' => 'TBA', 'lecturer' => 'Engr. MORANTE, AERONE',
        'times' => [['days' => ['Monday', 'Tuesday'], 'start' => '16:00', 'end' => '17:30']]
    ],
    'SOCIAL SCIENCE AND PHILOSOPHY' => [
        'code' => 'GE 11', 'room' => 'TBA', 'lecturer' => 'MONTESA, CLAIRE',
        'times' => [['days' => ['Monday', 'Tuesday'], 'start' => '17:30', 'end' => '19:00']]
    ],

    // Saturday
    'ETHICS' => [
        'code' => 'GE 9', 'room' => 'TBA', 'lecturer' => 'ORTIZ, ROWELLA',
        'times' => [['days' => ['Saturday'], 'start' => '07:00', 'end' => '10:00']]
    ],
    'MATH, SCIENCE & TECHNOLOGY' => [
        'code' => 'GE 10', 'room' => 'TBA', 'lecturer' => 'GONZALES, GILBERT',
        'times' => [['days' => ['Saturday'], 'start' => '10:00', 'end' => '13:00']]
    ],
    'ART AND HUMANITIES' => [
        'code' => 'GE 12', 'room' => 'TBA', 'lecturer' => 'LAGUNDAY, NICOLE',
        'times' => [['days' => ['Saturday'], 'start' => '16:00', 'end' => '19:00']]
    ]
];

echo "Seeding Schedule...\n";

try {
    // Ensure tables exist (running the db script logic implicitly via require, but let's be safe)
    // Actually db.php doesn't run creation automatically unless visited or logic triggered, 
    // but our edits to db.php put the arrays in. We need to iterate the tables array if we want to ensure creation.
    // However, existing usage implies tables are created on connection or manually. 
    // Let's manually trigger the creation loop from db.php logic just in case, or just trust the previous migrations.
    // simpler:
    $pdo->exec("CREATE TABLE IF NOT EXISTS schedules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject_id INTEGER NOT NULL,
            day_of_week TEXT NOT NULL, 
            start_time TEXT NOT NULL, 
            end_time TEXT NOT NULL
        )");

    // Clear existing schedules to avoid duplicates on re-run
    $pdo->exec("DELETE FROM schedules");
    
    foreach ($scheduleData as $subName => $data) {
        $times = $data['times'];
        $code = $data['code'];
        $room = $data['room'];
        $lecturer = $data['lecturer'];

        // 1. Find or Create Subject
        $stmt = $pdo->prepare("SELECT id FROM subjects WHERE name = ?");
        $stmt->execute([$subName]);
        $sub = $stmt->fetch();

        if ($sub) {
            $subId = $sub['id'];
            // Update info if exists
            $pdo->prepare("UPDATE subjects SET code=?, room=?, lecturer=? WHERE id=?")
                ->execute([$code, $room, $lecturer, $subId]);
            echo "Updated Subject: $subName ($subId)\n";
        } else {
            $pdo->prepare("INSERT INTO subjects (name, code, room, lecturer, semester) VALUES (?, ?, ?, ?, ?)")
                ->execute([$subName, $code, $room, $lecturer, $semester]);
            $subId = $pdo->lastInsertId();
            echo "Created Subject: $subName ($subId)\n";
        }

        // 2. Insert Schedules
        foreach ($times as $t) {
            foreach ($t['days'] as $day) {
                $pdo->prepare("INSERT INTO schedules (subject_id, day_of_week, start_time, end_time) VALUES (?, ?, ?, ?)")
                    ->execute([$subId, $day, $t['start'], $t['end']]);
                echo "  -> Added Schedule: $day {$t['start']} - {$t['end']}\n";
            }
        }
    }

    echo "Done!\n";

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
