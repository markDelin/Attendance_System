<?php
require 'includes/db.php';
$stmt = $pdo->query("SELECT * FROM subjects ORDER BY name");
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($rows as $r) {
    echo "ID: {$r['id']} | Name: {$r['name']} | Code: {$r['code']} | Sem: {$r['semester']}\n";
}
