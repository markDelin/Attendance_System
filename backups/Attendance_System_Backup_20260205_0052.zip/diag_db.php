<?php
// diag_db.php
date_default_timezone_set('Asia/Manila');
require_once 'includes/db.php';

echo "<h2>Diagnostic Info</h2>";
echo "Database Path: " . $database . "<br>";
echo "Current PHP Date: " . date('Y-m-d H:i:s') . "<br><br>";

// 1. Check Count
$count = $pdo->query("SELECT COUNT(*) FROM attendance")->fetchColumn();
echo "<b>Total Records:</b> $count<br>";

// 2. Check Today's records (strict match)
$today = date('Y-m-d');
$todayCount = $pdo->query("SELECT COUNT(*) FROM attendance WHERE date = '$today'")->fetchColumn();
echo "<b>Records for Today ($today):</b> $todayCount<br>";

// 3. Dump last 5 records raw
echo "<h3>Last 5 Records (Raw)</h3>";
$stmt = $pdo->query("SELECT * FROM attendance ORDER BY id DESC LIMIT 5");
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<pre>";
print_r($rows);
echo "</pre>";

// 4. Check for any records made today regardless of date column string
// (Maybe date was saved with time attached?)
echo "<h3>Checking for any records created recently (by ID)</h3>";
$stmt = $pdo->query("SELECT id, date, time, recorded_at FROM attendance ORDER BY id DESC LIMIT 5");
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "<pre>";
print_r($rows);
echo "</pre>";
?>
