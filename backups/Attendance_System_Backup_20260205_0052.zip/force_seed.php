<?php
// force_seed.php
date_default_timezone_set('Asia/Manila');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'includes/db.php';

// Check DB file location
echo "DB Path: " . $database . "<br>";
if (!is_writable($database)) {
    echo "WARNING: Database file is not writable!<br>";
}

$today = date('Y-m-d');
$qr = 'TEST-QR-' . time();

echo "Attempting to insert record for $today...<br>";

try {
    $stmt = $pdo->prepare("INSERT INTO attendance (qr_code, date, time, status, session) VALUES (?, ?, ?, ?, ?)");
    // Use a hardcoded QR for testing if users doesn't exist, but foreign key might fail.
    // Let's pick a valid user.
    $u = $pdo->query("SELECT qr_code FROM users LIMIT 1")->fetchColumn();
    
    if (!$u) {
        die("No users found. Cannot insert.");
    }
    
    $stmt->execute([$u, $today, '12:00', 'present', 'morning']);
    echo "Insert executed.<br>";
    
    // Check immediately
    $check = $pdo->query("SELECT count(*) FROM attendance WHERE date = '$today'")->fetchColumn();
    echo "Count for $today is now: $check<br>";
    
} catch (PDOException $e) {
    echo "SQL Error: " . $e->getMessage() . "<br>";
}
?>
