<?php
// includes/navbar.php
$currentPage = basename($_SERVER['PHP_SELF']);
$isHome = $currentPage === 'index.php';
$title = 'Attendance System';

// Determine Header Title based on page
switch($currentPage) {
    case 'scan.php': $title = 'Scan QR'; break;
    case 'manual.php': $title = 'Manual Entry'; break;
    case 'view_attendance.php': $title = 'Records'; break;
    case 'manage_students.php': $title = 'Manage Students'; break;
    case 'schedule.php': $title = 'Schedule Maker'; break;
    case 'calendar.php': $title = 'Calendar'; break;
    case 'settings.php': $title = 'Settings'; break;
    case 'view_subjects_list.php': $title = 'Subject List'; break;
}
?>

<!-- Desktop Top Navbar -->
<nav class="navbar animate-fade-up">
    <?php if ($isHome): ?>
        <div class="brand flex-center" style="gap: 12px;">
            <i class="bi bi-qr-code-scan" style="color: var(--primary); font-size: 1.5rem;"></i>
            <h3>QR Tools<span class="text-gradient"> by MCK</span></h3>
        </div>
        <div>
            <span class="badge" style="background: transparent; border: 1px solid var(--border); color: var(--text-muted);">
                <?= date('F j, Y'); ?>
            </span>
        </div>
    <?php else: ?>
        <div class="flex-center" style="gap: 12px;">
            <a href="index.php" class="btn btn-ghost" style="padding: 0.5rem; border-radius: 50%; width: 40px; height: 40px; display: flex; justify-content: center; align-items: center;">
                <i class="bi bi-arrow-left" style="font-size: 1.2rem;"></i>
            </a>
            <h3><?= $title ?></h3>
        </div>
        
        <div class="flex-center" style="gap: 10px;">
            <?php if (isset($show_clock) && $show_clock): ?>
                <div class="flex-center d-none-mobile" style="gap: 8px; margin-right: 10px;">
                    <i class="bi bi-clock" style="color: var(--secondary);"></i> 
                    <span id="clock" style="font-weight: 600; font-size: 0.9rem;"><?= date('h:i A') ?></span>
                </div>
            <?php endif; ?>

            <?php if (isset($navbar_actions)): ?>
                <?= $navbar_actions ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</nav>

<!-- Mobile Bottom Navigation -->
<nav class="bottom-nav">
    <div class="bottom-nav-items">
        
        <a href="index.php" class="nav-item <?= $isHome ? 'active' : '' ?>">
            <i class="bi bi-house<?= $isHome ? '-fill' : '' ?>"></i>
            <span>Home</span>
        </a>

        <a href="view_attendance.php" class="nav-item <?= $currentPage === 'view_attendance.php' ? 'active' : '' ?>">
            <i class="bi bi-journal-text"></i>
            <span>Records</span>
        </a>

        <!-- FAB for Scan -->
        <a href="scan.php" class="nav-fab animate-fade-up delay-1">
            <i class="bi bi-qr-code-scan"></i>
        </a>

        <a href="schedule.php" class="nav-item <?= $currentPage === 'schedule.php' ? 'active' : '' ?>">
            <i class="bi bi-calendar-event<?= $currentPage === 'schedule.php' ? '-fill' : '' ?>"></i>
            <span>Schedule</span>
        </a>

        <a href="manage_students.php" class="nav-item <?= $currentPage === 'manage_students.php' ? 'active' : '' ?>">
            <i class="bi bi-person-gear"></i>
            <span>Students</span>
        </a>

    </div>
</nav>
