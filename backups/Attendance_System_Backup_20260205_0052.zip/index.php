<?php
// index.php - Student Attendance System
date_default_timezone_set('Asia/Manila');
require_once 'includes/db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | QR Tools by MCK</title>
    <link href="assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/vendor/bootstrap-icons/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Dashboard Cards */
        .stat-card {
            background: white; border-radius: var(--radius-lg); padding: 1.5rem;
            box-shadow: var(--shadow-sm); border: 1px solid var(--border);
            transition: transform 0.2s;
            display: flex; flex-direction: column; justify-content: space-between;
        }
        .stat-card:hover { transform: translateY(-2px); box-shadow: var(--shadow-md); }
        .stat-icon {
            width: 48px; height: 48px; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.5rem; margin-bottom: 1rem;
        }
        
        .grid-stats {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.5rem; margin-top: 2rem; margin-bottom: 2rem;
        }
        
        .charts-section {
            display: grid; grid-template-columns: 1fr 1.5fr; gap: 1.5rem; margin-bottom: 3rem;
        }
        @media (max-width: 900px) { .charts-section { grid-template-columns: 1fr; } }
        
        .chart-container {
            background: white; border-radius: var(--radius-lg); padding: 1.5rem;
            border: 1px solid var(--border); box-shadow: var(--shadow-sm);
            height: 400px; /* Increased height to fit legend */
            position: relative;
            display: flex; flex-direction: column;
        }
        canvas {
            flex: 1; min-height: 0; /* Critical for chart.js flex resizing */
        }
        
        .quick-actions {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(145px, 1fr)); gap: 1rem;
        }
        .action-btn {
            background: white; border: 1px solid var(--border); border-radius: var(--radius-md);
            padding: 1.25rem 1rem; text-align: center; text-decoration: none; color: var(--text-main);
            transition: all 0.2s; display: flex; flex-direction: column; align-items: center; justify-content: center;
            min-height: 120px;
        }
        
        @media (max-width: 600px) {
            .quick-actions { grid-template-columns: 1fr 1fr; gap: 0.75rem; }
            .action-btn { padding: 1rem 0.5rem; min-height: 110px; }
            .action-btn i { font-size: 1.5rem; margin-bottom: 0.5rem; }
            .action-btn span { font-size: 0.85rem; }
        }
        
        /* Stats Colors */
        .bg-blue { background: #eff6ff; color: var(--primary); }
        .bg-green { background: #f0fdf4; color: var(--success); }
        .bg-orange { background: #fff7ed; color: var(--warning); }
        .bg-red { background: #fef2f2; color: var(--danger); }
    </style>
</head>
<body>

    <!-- Navigation -->
    <?php include 'includes/navbar.php'; ?>

    <!-- Main Content -->
    <main class="container">
        
        <div style="margin-top: 2rem; display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h2 style="margin: 0; font-size: 1.75rem;">Dashboard</h2>
                <p style="color: var(--text-muted);"><?= date('l, F j, Y') ?></p>
            </div>
            <a href="scan.php" class="btn btn-primary" style="padding: 0.75rem 1.5rem;">
                <i class="bi bi-qr-code-scan"></i> <span class="d-none-mobile">Scan Now</span>
            </a>
        </div>





        <!-- 3. Quick Actions -->
        <section style="margin-bottom: 4rem;" class="animate-fade-up delay-2">
            <h4 style="margin-bottom: 1rem; color: var(--text-muted); font-weight: 600; text-transform: uppercase; font-size: 0.85rem; letter-spacing: 1px;">Quick Actions</h4>
            <div class="quick-actions">
                <a href="scan.php" class="action-btn">
                    <i class="bi bi-qr-code" style="color: var(--primary);"></i>
                    <span>Scanner</span>
                </a>
                <a href="manual.php" class="action-btn">
                    <i class="bi bi-pen" style="color: var(--success);"></i>
                    <span>Manual Entry</span>
                </a>
                <a href="view_attendance.php" class="action-btn">
                    <i class="bi bi-table" style="color: var(--warning);"></i>
                    <span>Records</span>
                </a>
                <a href="manage_students.php" class="action-btn">
                    <i class="bi bi-people" style="color: var(--accent);"></i>
                    <span>Students</span>
                </a>
                <a href="groups.php" class="action-btn">
                    <i class="bi bi-shuffle" style="color: #d946ef;"></i>
                    <span>Randomizer</span>
                </a>
                <a href="schedule.php" class="action-btn">
                    <i class="bi bi-calendar-week" style="color: #f43f5e;"></i>
                    <span>Schedule</span>
                </a>
                <a href="calendar.php" class="action-btn">
                    <i class="bi bi-calendar3" style="color: #6366f1;"></i>
                    <span>Calendar</span>
                </a>
                <a href="settings.php" class="action-btn">
                    <i class="bi bi-gear" style="color: var(--secondary);"></i>
                    <span>Settings</span>
                </a>
            </div>
        </section>

    </main>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            fetchDashboardData();
        });

        function fetchDashboardData() {
            // Keep fetching because maybe we'll use it later?
            // Actually, if we remove stats AND charts, do we need to fetch anything?
            // "Main page" usually implies Dashboard.
            // If everything is removed, dashboard is just a menu.
            // Let's remove the fetch entirely if it does nothing.
        }

        function animateValue(id, start, end, duration) {
            const obj = document.getElementById(id);
            let startTimestamp = null;
            const step = (timestamp) => {
                if (!startTimestamp) startTimestamp = timestamp;
                const progress = Math.min((timestamp - startTimestamp) / duration, 1);
                obj.innerHTML = Math.floor(progress * (end - start) + start);
                if (progress < 1) {
                    window.requestAnimationFrame(step);
                }
            };
            window.requestAnimationFrame(step);
        }
    </script>
</body>
</html>
