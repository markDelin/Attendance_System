<?php
// manage_students.php - Manage Users
date_default_timezone_set('Asia/Manila');
require_once 'includes/db.php';

// Fetch users
$stmt = $pdo->query("SELECT * FROM users ORDER BY name");
$allUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);

$regularUsers = array_filter($allUsers, function($u) {
    return ($u['student_type'] ?? 'regular') === 'regular';
});
$irregularUsers = array_filter($allUsers, function($u) {
    return ($u['student_type'] ?? 'regular') !== 'regular';
});
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students | QR Tools by MCK</title>
    <link href="assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/vendor/bootstrap-icons/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .search-area {
            position: sticky;
            top: var(--header-height);
            z-index: 90;
            background: rgba(248, 250, 252, 0.9);
            backdrop-filter: blur(5px);
            padding: 1rem 0;
            border-bottom: 1px solid var(--border);
            margin-bottom: 2rem;
        }
        
        @media (max-width: 768px) {
            .search-area { top: auto; } /* Adjust because mobile header auto-height */
        }

        .user-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1.25rem;
            padding-bottom: 4rem;
        }

        .user-card {
            background: white;
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            padding: 1.5rem;
            position: relative;
            box-shadow: var(--shadow-sm);
        }

        .avatar {
            width: 40px; height: 40px;
            border-radius: 50%;
            background: #e2e8f0;
            color: var(--text-muted);
            font-weight: 600;
            display: flex; align-items: center; justify-content: center;
            margin-bottom: 1rem;
        }

        .action-btn {
            padding: 0.4rem 0.8rem;
            font-size: 0.85rem;
            border-radius: var(--radius-sm);
            cursor: pointer;
            border: 1px solid var(--border);
            background: white;
            transition: all 0.2s;
        }
        .action-btn:hover { background: #f1f5f9; }
        .edit-btn { color: var(--primary); }
        .delete-btn { color: var(--danger); border-color: #fecaca; background: #fef2f2; }
        .delete-btn:hover { background: #fee2e2; }
        
        .section-title {
            margin: 2rem 0 1rem;
            font-size: 1.2rem;
            color: var(--text-main);
            border-bottom: 2px solid var(--border);
            padding-bottom: 0.5rem;
            display: flex; justify-content: space-between; align-items: center;
        }
    </style>
</head>
<body>

    <!-- Nav (Standardized) -->
    <?php 
    $navbar_actions = '
        <button onclick="addStudent()" class="btn btn-primary" style="padding: 0.5rem 1rem; border-radius: 20px;">
            <i class="bi bi-person-plus"></i> Add
        </button>
    ';
    include 'includes/navbar.php'; 
    ?>
    </nav>

    <!-- Search -->
    <div class="search-area">
        <div class="container">
            <div style="position: relative;">
                <i class="bi bi-search" style="position: absolute; left: 1rem; top: 50%; transform: translateY(-50%); color: var(--text-muted);"></i>
                <input type="text" id="searchInput" class="form-control" placeholder="Search students..." autocomplete="off" style="padding-left: 3rem;">
            </div>
        </div>
    </div>

    <main class="container">
        
        <!-- Regular Students -->
        <div class="section-title">
            <span>Regular Class List</span>
            <span class="badge" style="background:var(--bg-main); border:1px solid var(--border);"><?= count($regularUsers) ?></span>
        </div>
        <div id="regularGrid" class="user-grid animate-fade-up">
            <?php foreach ($regularUsers as $user): ?>
                <?php renderUserCard($user); ?>
            <?php endforeach; ?>
            <?php if(empty($regularUsers)): ?>
                <p style="color:var(--text-muted);">No regular students found.</p>
            <?php endif; ?>
        </div>

        <!-- Irregular Students -->
        <div class="section-title" style="margin-top: 3rem;">
            <span>Irregular / Other Students</span>
            <span class="badge" style="background:var(--bg-main); border:1px solid var(--border);"><?= count($irregularUsers) ?></span>
        </div>
        <div id="irregularGrid" class="user-grid animate-fade-up delay-1">
            <?php foreach ($irregularUsers as $user): ?>
                <?php renderUserCard($user); ?>
            <?php endforeach; ?>
             <?php if(empty($irregularUsers)): ?>
                <p style="color:var(--text-muted);">No irregular students found.</p>
            <?php endif; ?>
        </div>

    </main>
    
    <?php
    function renderUserCard($user) {
        $firstName = $user['first_name'] ?? '';
        $lastName = $user['last_name'] ?? '';
        $mi = $user['middle_initial'] ?? '';

        // Fallback: Parse Name if individual fields are empty
        if (empty($firstName) && empty($lastName)) {
            $parts = explode(',', $user['name']);
            if (count($parts) >= 2) {
                $lastName = trim($parts[0]);
                $rest = trim($parts[1]);
                
                // Try to extract MI from end of rest (e.g. "John A.")
                if (preg_match('/(.*)\s([A-Z])\.?$/', $rest, $matches)) {
                    $firstName = trim($matches[1]);
                    $mi = $matches[2];
                } else {
                    $firstName = $rest;
                }
            } else {
                // Just use full name as First Name if no comma
                $firstName = $user['name'];
            }
        }
        ?>
        <div class="user-card" 
             id="card-<?= htmlspecialchars($user['qr_code']) ?>"
             data-qr="<?= htmlspecialchars($user['qr_code']) ?>"
             data-name="<?= htmlspecialchars($user['name']) ?>"
             data-firstname="<?= htmlspecialchars($firstName) ?>"
             data-lastname="<?= htmlspecialchars($lastName) ?>"
             data-middle="<?= htmlspecialchars($mi) ?>"
             data-course="<?= htmlspecialchars($user['course'] ?? '') ?>"
             data-type="<?= htmlspecialchars($user['student_type'] ?? 'regular') ?>"
             data-birthday="<?= htmlspecialchars($user['birthday'] ?? '') ?>"
             data-place-of-birth="<?= htmlspecialchars($user['place_of_birth'] ?? '') ?>"
             data-sex="<?= htmlspecialchars($user['sex'] ?? '') ?>"
             data-civil-status="<?= htmlspecialchars($user['civil_status'] ?? '') ?>"
             data-religion="<?= htmlspecialchars($user['religion'] ?? '') ?>"
             data-citizenship="<?= htmlspecialchars($user['citizenship'] ?? '') ?>"
             data-citizenship="<?= htmlspecialchars($user['citizenship'] ?? '') ?>"
             data-contact="<?= htmlspecialchars($user['contact_number'] ?? '') ?>"
             data-section="<?= htmlspecialchars($user['section'] ?? '') ?>"
        >
            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                <div class="avatar">
                    <?= strtoupper(substr($user['name'], 0, 1)) ?>
                </div>
                <div style="overflow: hidden;">
                    <h5 onclick="window.location.href='profile.php?qr=<?= urlencode($user['qr_code']) ?>'" style="cursor: pointer; text-decoration: underline; text-underline-offset: 4px; margin: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"><?= htmlspecialchars($user['name']) ?></h5>
                    <small style="color: var(--text-muted); font-size: 0.75rem;">
                        ID: <?= substr($user['qr_code'], 0, 8) ?>...
                    </small>
                </div>
            </div>
            <div style="display: flex; gap: 0.5rem; margin-top: auto;">
                <button onclick="editUser('<?= htmlspecialchars($user['qr_code']) ?>')" 
                        class="action-btn edit-btn" style="flex: 1;" title="Edit Details">
                    <i class="bi bi-pencil"></i>
                </button>
                
                <?php if(($user['student_type'] ?? 'regular') === 'irregular'): ?>
                <button onclick="manageSubjects('<?= htmlspecialchars($user['qr_code']) ?>', '<?= htmlspecialchars($user['name']) ?>')" 
                        class="action-btn" style="flex: 1; color: var(--warning); border-color: #fde68a; background: #fffbeb;" title="Manage Subjects">
                    <i class="bi bi-journal-check"></i>
                </button>
                <?php endif; ?>

                <a href="student_history.php?qr_code=<?= urlencode($user['qr_code']) ?>" 
                   class="action-btn" style="flex: 1; text-align: center; color: var(--text-main); text-decoration: none;" title="View History">
                    <i class="bi bi-clock-history"></i>
                </a>
                <button onclick="deleteUser('<?= htmlspecialchars($user['qr_code']) ?>', '<?= htmlspecialchars($user['name']) ?>')" 
                        class="action-btn delete-btn" style="flex: 1;" title="Delete Student">
                    <i class="bi bi-trash"></i>
                </button>
            </div>
        </div>
        <?php
    }
    ?>

    <script>
        // Search
        document.getElementById('searchInput').addEventListener('input', (e) => {
            const term = e.target.value.toLowerCase();
            document.querySelectorAll('.user-card').forEach(card => {
                const name = card.dataset.name.toLowerCase();
                card.style.display = name.includes(term) ? 'block' : 'none';
            });
        });

        function addStudent() {
            Swal.fire({
                title: 'Add New Student',
                width: 'auto',
                customClass: {
                    popup: 'responsive-modal'
                },
                html: `
                    <style>
                        .swal-grid-2 { display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:10px; }
                        .swal2-input, .swal2-select { 
                            margin: 5px 0 !important; 
                            width: 100% !important; 
                            font-size: 0.9rem !important;
                             height: auto !important;
                            padding: 0.6rem !important;
                        }
                        .swal2-select { padding-right: 2rem !important; }
                        @media (max-width: 600px) {
                            .swal-grid-2 { grid-template-columns: 1fr; gap:5px; }
                        }
                    </style>
                    <div style="text-align:left; display:flex; flex-direction:column; gap:10px;">
                        
                        <div class="form-floating-custom">
                             <label><i class="bi bi-qr-code"></i> Student ID / QR Code *</label>
                             <input type="text" id="swal-id" class="swal2-input" placeholder="e.g. 2024-0001">
                        </div>

                        <div class="swal-grid-2">
                            <div>
                                <label style="font-size:0.85rem; font-weight:600; color:#555;">First Name *</label>
                                <input type="text" id="swal-firstname" class="swal2-input" placeholder="John">
                            </div>
                            <div>
                                <label style="font-size:0.85rem; font-weight:600; color:#555;">Last Name *</label>
                                <input type="text" id="swal-lastname" class="swal2-input" placeholder="Doe">
                            </div>
                        </div>
                        
                        <div class="swal-grid-2">
                             <div>
                                <label style="font-size:0.85rem; font-weight:600; color:#555;">Course / Strand</label>
                                <input type="text" id="swal-course" class="swal2-input" placeholder="BSIS">
                            </div>
                             <div>
                                <label style="font-size:0.85rem; font-weight:600; color:#555;">Section / Set</label>
                                <input type="text" id="swal-section" class="swal2-input" placeholder="2-A">
                            </div>
                        </div>

                         <div class="swal-grid-2">
                             <div>
                                <label style="font-size:0.85rem; font-weight:600; color:#555;">M.I.</label>
                                <input type="text" id="swal-middle" class="swal2-input" maxlength="3" placeholder="M.">
                            </div>
                             <div>
                                <label style="font-size:0.85rem; font-weight:600; color:#555;">Student Type</label>
                                <select id="swal-type" class="swal2-select" style="width:100%;">
                                    <option value="regular" selected>Regular Student</option>
                                    <option value="irregular">Irregular / Other</option>
                                </select>
                            </div>
                        </div>

                        <div style="margin-top:10px; font-size:0.85rem; color:#666; font-style:italic; background:#f8fafc; padding:8px; border-radius:6px;">
                            <i class="bi bi-info-circle"></i> Basic info only. You can add full details (Birthday, Contact, etc.) later by editing the student profile.
                        </div>
                    </div>
                `,
                showCancelButton: true,
                confirmButtonText: '<i class="bi bi-person-plus"></i> Add Student',
                confirmButtonColor: 'var(--primary)',
                preConfirm: () => {
                   return {
                       qr_code: document.getElementById('swal-id').value.trim(),
                       first_name: document.getElementById('swal-firstname').value.trim(),
                       last_name: document.getElementById('swal-lastname').value.trim(),
                       middle_initial: document.getElementById('swal-middle').value.trim(),
                       student_type: document.getElementById('swal-type').value,
                       course: document.getElementById('swal-course').value.trim(),
                       section: document.getElementById('swal-section').value.trim()
                   };
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    const data = result.value;
                    if (!data.qr_code || !data.first_name || !data.last_name) {
                         Swal.fire('Error', 'ID, First Name, and Last Name are required.', 'error');
                         return;
                    }

                    fetch('api/manage_users.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({ action: 'add', ...data })
                    })
                    .then(r => r.json())
                    .then(res => {
                        if(res.status === 'success') {
                             Swal.fire('Added!', 'New student registered successfully.', 'success').then(() => location.reload());
                        } else {
                             Swal.fire('Error', res.message, 'error');
                        }
                    })
                    .catch(() => Swal.fire('Error', 'Network Error', 'error'));
                }
            });
        }

        function editUser(qr_code) {
           const card = document.getElementById('card-' + qr_code);
           const d = card.dataset;
           
            Swal.fire({
                title: 'Edit Student',
                width: 'auto',
                customClass: {
                    popup: 'responsive-modal'
                },
                html: `
                    <style>
                        .swal-grid-2 { display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:10px; }
                        /* Override SweetAlert2 default input styles to fit grid */
                        .swal2-input, .swal2-select { 
                            margin: 5px 0 !important; 
                            width: 100% !important; 
                            font-size: 0.9rem !important;
                            height: auto !important;
                            padding: 0.6rem !important;
                        }
                        .swal2-select { padding-right: 2rem !important; }
                        
                        @media (max-width: 600px) {
                            .swal-grid-2 { grid-template-columns: 1fr; gap:5px; }
                            .responsive-modal { width: 95% !important; padding: 0.5em !important; }
                        }
                    </style>
                    <div style="text-align:left; max-height:70vh; overflow-y:auto; overflow-x:hidden; padding: 0 5px;">
                        
                        <!-- Section: Identity -->
                        <h6 style="color:var(--primary); border-bottom:1px solid #eee; padding-bottom:5px; margin-bottom:10px;">Identity</h6>
                        <div class="swal-grid-2">
                             <div>
                                <label style="font-size:0.8rem; font-weight:bold;">First Name *</label>
                                <input type="text" id="edit-firstname" class="swal2-input" value="${d.firstname}">
                            </div>
                            <div>
                                <label style="font-size:0.8rem; font-weight:bold;">Last Name *</label>
                                <input type="text" id="edit-lastname" class="swal2-input" value="${d.lastname}">
                            </div>
                        </div>
                        <div class="swal-grid-2" style="grid-template-columns: 80px 1fr;">
                             <div>
                                <label style="font-size:0.8rem; font-weight:bold;">M.I.</label>
                                <input type="text" id="edit-middle" class="swal2-input" value="${d.middle}" maxlength="3">
                            </div>
                             <div>
                                <label style="font-size:0.8rem; font-weight:bold;">Student Type</label>
                                <select id="edit-type" class="swal2-select" style="width:100%;">
                                    <option value="regular" ${d.type === 'regular' ? 'selected' : ''}>Regular</option>
                                    <option value="irregular" ${d.type === 'irregular' ? 'selected' : ''}>Irregular / Other</option>
                                </select>
                            </div>
                        </div>
                        
                         <!-- Section: Personal Details -->
                        <h6 style="color:var(--primary); border-bottom:1px solid #eee; padding-bottom:5px; margin-bottom:10px; margin-top:20px;">Personal Details</h6>
                        
                        <div class="swal-grid-2">
                             <div>
                                 <label style="font-size:0.8rem; font-weight:bold;">Course / Strand</label>
                                 <input type="text" id="edit-course" class="swal2-input" value="${d.course}" placeholder="e.g. BSCS">
                            </div>
                            <div>
                                 <label style="font-size:0.8rem; font-weight:bold;">Section / Set</label>
                                 <input type="text" id="edit-section" class="swal2-input" value="${d.section || ''}" placeholder="e.g. 2-A">
                            </div>
                        </div>

                         <div class="swal-grid-2">
                             <div>
                                <label style="font-size:0.8rem; font-weight:bold;">Birthday</label>
                                <input type="date" id="edit-birthday" class="swal2-input" value="${d.birthday}">
                            </div>
                            <div>
                                <label style="font-size:0.8rem; font-weight:bold;">Sex</label>
                                <select id="edit-sex" class="swal2-select" style="width:100%;">
                                    <option value="" disabled ${!d.sex ? 'selected' : ''}>Select...</option>
                                    <option value="Male" ${d.sex === 'Male' ? 'selected' : ''}>Male</option>
                                    <option value="Female" ${d.sex === 'Female' ? 'selected' : ''}>Female</option>
                                </select>
                            </div>
                        </div>

                         <div class="swal-grid-2">
                             <div>
                                <label style="font-size:0.8rem; font-weight:bold;">Civil Status</label>
                                 <select id="edit-civil" class="swal2-select" style="width:100%;">
                                    <option value="" disabled ${!d.civilStatus ? 'selected' : ''}>Select...</option>
                                    <option value="Single" ${d.civilStatus === 'Single' ? 'selected' : ''}>Single</option>
                                    <option value="Married" ${d.civilStatus === 'Married' ? 'selected' : ''}>Married</option>
                                    <option value="Widowed" ${d.civilStatus === 'Widowed' ? 'selected' : ''}>Widowed</option>
                                </select>
                            </div>
                            <div>
                                <label style="font-size:0.8rem; font-weight:bold;">Religion</label>
                                <input type="text" id="edit-religion" class="swal2-input" value="${d.religion}">
                            </div>
                        </div>
                        
                        <div style="margin-bottom:10px;">
                             <label style="font-size:0.8rem; font-weight:bold;">Place of Birth</label>
                             <input type="text" id="edit-pob" class="swal2-input" value="${d.placeOfBirth}">
                        </div>

                         <!-- Section: Contact -->
                        <h6 style="color:var(--primary); border-bottom:1px solid #eee; padding-bottom:5px; margin-bottom:10px; margin-top:20px;">Contact Info</h6>

                         <div class="swal-grid-2">
                             <div>
                                <label style="font-size:0.8rem; font-weight:bold;">Contact Number</label>
                                <input type="text" id="edit-contact" class="swal2-input" value="${d.contact}">
                            </div>
                            <div>
                                <label style="font-size:0.8rem; font-weight:bold;">Citizenship</label>
                                <input type="text" id="edit-citizenship" class="swal2-input" value="${d.citizenship}">
                            </div>
                        </div>

                    </div>
                `,
                showCancelButton: true,
                confirmButtonText: 'Save Changes',
                confirmButtonColor: 'var(--primary)',
                preConfirm: () => {
                   return {
                       qr_code: qr_code, // Keep original QR
                       first_name: document.getElementById('edit-firstname').value.trim(),
                       last_name: document.getElementById('edit-lastname').value.trim(),
                       middle_initial: document.getElementById('edit-middle').value.trim(),
                       birthday: document.getElementById('edit-birthday').value,
                       course: document.getElementById('edit-course').value.trim(),
                       sex: document.getElementById('edit-sex').value,
                       civil_status: document.getElementById('edit-civil').value,
                       religion: document.getElementById('edit-religion').value.trim(),
                       citizenship: document.getElementById('edit-citizenship').value.trim(),
                       contact_number: document.getElementById('edit-contact').value.trim(),
                       place_of_birth: document.getElementById('edit-pob').value.trim(),
                       student_type: document.getElementById('edit-type').value,
                       section: document.getElementById('edit-section').value.trim()
                   };
                }
            }).then((result) => {
                if (result.isConfirmed) {
                     const data = result.value;
                    if (!data.first_name || !data.last_name) {
                         Swal.fire('Error', 'First Name and Last Name are required.', 'error');
                         return;
                    }
                     fetch('api/manage_users.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({ action: 'update', ...data })
                    })
                    .then(r => r.json())
                    .then(res => {
                        if(res.status === 'success') {
                             Swal.fire('Updated!', 'Student updated successfully.', 'success').then(() => location.reload());
                        } else {
                             Swal.fire('Error', res.message, 'error');
                        }
                    })
                    .catch(() => Swal.fire('Error', 'Network Error', 'error'));
                }
            });
        }

        function deleteUser(id, name) {
            Swal.fire({
                title: 'Delete Student?',
                text: `This will delete ${name} and ALL their attendance history.`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'Yes, delete!'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('api/manage_users.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({ action: 'delete', qr_code: id })
                    })
                    .then(r => r.json())
                    .then(data => {
                        if(data.status === 'success') {
                            Swal.fire('Deleted!', 'Student has been removed.', 'success')
                                .then(() => location.reload());
                        } else {
                            Swal.fire('Error', data.message, 'error');
                        }
                    });
                }
            });
        }

        function manageSubjects(qr, name) {
            Swal.fire({
                title: 'Loading Subjects...',
                didOpen: () => { Swal.showLoading(); }
            });
            
            fetch('api/manage_enrollment.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ action: 'get_enrollments', qr_code: qr })
            })
            .then(r => r.json())
            .then(data => {
                Swal.close();
                if(data.status !== 'success') {
                    Swal.fire('Error', data.message, 'error');
                    return;
                }
                
                // Build Checkbox List
                let html = '<div style="text-align:left; max-height:300px; overflow-y:auto; border:1px solid #ddd; padding:10px;">';
                if(data.all_subjects.length === 0) {
                    html += '<p style="color:#666; font-style:italic;">No subjects available. Please create subjects first.</p>';
                } else {
                    // Ensure all IDs are strings for comparison
                    const enrolledSet = new Set(data.enrolled_ids.map(String));
                    
                    data.all_subjects.forEach(sub => {
                        const isChecked = enrolledSet.has(String(sub.id)) ? 'checked' : '';
                        html += `
                            <div style="margin-bottom:8px;">
                                <label style="cursor:pointer; display:flex; align-items:center;">
                                    <input type="checkbox" class="swal-sub-check" value="${sub.id}" ${isChecked} style="margin-right:10px; transform:scale(1.2);">
                                    <span>${sub.name}</span>
                                </label>
                            </div>
                        `;
                    });
                }
                html += '</div>';
                
                Swal.fire({
                    title: `Manage Subjects for<br>${name}`,
                    html: html,
                    showCancelButton: true,
                    confirmButtonText: 'Save Enrollment',
                    confirmButtonColor: 'var(--primary)',
                    preConfirm: () => {
                        const checked = Array.from(document.querySelectorAll('.swal-sub-check:checked')).map(el => el.value);
                        return fetch('api/manage_enrollment.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                            body: new URLSearchParams({ 
                                action: 'save_enrollments', 
                                qr_code: qr,
                                subjects: JSON.stringify(checked)
                            })
                        })
                        .then(r => r.json())
                        .then(res => {
                            if(res.status !== 'success') throw new Error(res.message);
                            return res;
                        })
                        .catch(err => {
                            Swal.showValidationMessage(err.message);
                        });
                    }
                }).then(res => {
                    if(res.isConfirmed) {
                        Swal.fire('Success', 'Subject enrollment updated.', 'success');
                    }
                });
            })
            .catch(err => Swal.fire('Error', 'Failed to load subjects', 'error'));
        }
    </script>
</body>
</html>
