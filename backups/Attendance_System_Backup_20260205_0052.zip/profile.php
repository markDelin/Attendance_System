<?php
// profile.php - Student Profile V2
date_default_timezone_set('Asia/Manila');
require_once 'includes/db.php';

$qr = $_GET['qr'] ?? '';
if (empty($qr)) header('Location: manual.php');

// Handle Profile Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $middle_initial = trim($_POST['middle_initial'] ?? '');
    
    // Construct Name
    $name = $last_name . ', ' . $first_name . ($middle_initial ? ' ' . $middle_initial . '.' : '');
    
    // Other fields
    $course = $_POST['course'] ?? '';
    $sex = $_POST['sex'] ?? '';
    $birthday = !empty($_POST['birthday']) ? $_POST['birthday'] : null;
    $email = !empty($_POST['email']) ? trim($_POST['email']) : null;
    $pob = $_POST['place_of_birth'] ?? '';
    $civil = $_POST['civil_status'] ?? '';
    $religion = $_POST['religion'] ?? '';
    $citizenship = $_POST['citizenship'] ?? '';
    $contact = $_POST['contact_number'] ?? '';
    
    try {
        $stmt = $pdo->prepare("UPDATE users SET 
            name = ?, first_name = ?, last_name = ?, middle_initial = ?, 
            birthday = ?, email = ?, course = ?, sex = ?, 
            place_of_birth = ?, civil_status = ?, religion = ?, citizenship = ?, contact_number = ?
            WHERE qr_code = ?");
        $stmt->execute([
            $name, $first_name, $last_name, $middle_initial, 
            $birthday, $email, $course, $sex, 
            $pob, $civil, $religion, $citizenship, $contact, 
            $qr
        ]);
        header("Location: profile.php?qr=$qr&msg=saved");
        exit;
    } catch (Exception $e) {
        $error = "Error updating profile: " . $e->getMessage();
    }
}

// Fetch User
$stmt = $pdo->prepare("SELECT * FROM users WHERE qr_code = ?");
$stmt->execute([$qr]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) die("User not found.");

// ... (Stats fetching remains same) ...

// Fetch Attendance Stats
$totalClasses = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE qr_code = ?");
$totalClasses->execute([$qr]);
$totalClasses = $totalClasses->fetchColumn();

$present = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE qr_code = ? AND status = 'present'");
$present->execute([$qr]);
$present = $present->fetchColumn();

$late = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE qr_code = ? AND status = 'late'");
$late->execute([$qr]);
$late = $late->fetchColumn();

$absent = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE qr_code = ? AND status = 'absent'");
$absent->execute([$qr]);
$absent = $absent->fetchColumn();

$rate = $totalClasses > 0 ? round((($present + $late) / $totalClasses) * 100) : 0;

// Fetch Recent Activity
$stmt = $pdo->prepare("SELECT * FROM attendance WHERE qr_code = ? ORDER BY date DESC, time DESC LIMIT 20");
$stmt->execute([$qr]);
$history = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($user['name']) ?> | Profile</title>
    <link href="assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/vendor/bootstrap-icons/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .stat-card {
            background: white; padding: 1.5rem; border-radius: var(--radius-md);
            border: 1px solid var(--border); text-align: center;
        }
        .stat-val { font-size: 2rem; font-weight: 700; color: var(--primary); }
        .stat-label { color: var(--text-muted); font-size: 0.9rem; }
        
        .history-item {
            display: flex; justify-content: space-between; align-items: center;
            padding: 1rem; border-bottom: 1px solid var(--border);
            background: white;
        }
        .history-item:last-child { border: none; }
        
        .info-group { margin-bottom: 1rem; text-align: left; }
        .info-label { font-size: 0.85rem; color: var(--text-muted); font-weight: 600; display: block; margin-bottom: 0.25rem; }
        .info-value { font-size: 1rem; color: var(--text-main); }
        .info-placeholder { color: var(--text-muted); font-style: italic; font-size: 0.9rem; }

        /* Modal Styles */
        .modal {
            display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%;
            background-color: rgba(0,0,0,0.5); align-items: center; justify-content: center;
        }
        .modal-content {
            background-color: #fff; padding: 2rem; border-radius: var(--radius-lg);
            width: 90%; max-width: 600px; position: relative;
            box-shadow: var(--shadow-lg); animation: slideUp 0.3s ease;
            max-height: 90vh; overflow-y: auto;
        }
        @keyframes slideUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="manage_students.php" class="btn btn-ghost" style="border: none; padding-left: 0;">
            <i class="bi bi-arrow-left"></i> Back
        </a>
        <h3 class="text-gradient">Profile</h3>
        <div style="width: 40px;"></div>
    </nav>

    <main class="container" style="max-width: 800px; padding-top: 2rem;">
        
        <!-- Header & Info -->
        <div class="card animate-fade-up" style="padding: 2rem; text-align: center; margin-bottom: 2rem; position: relative;">
            
            <button onclick="openEditModal()" class="btn btn-ghost" style="position: absolute; top: 1rem; right: 1rem; color: var(--primary);">
                <i class="bi bi-pencil-square"></i> Edit
            </button>

            <div style="width: 80px; height: 80px; background: var(--bg-main); border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center; font-size: 2rem; font-weight: 700; color: var(--text-muted);">
                <?= strtoupper(substr($user['first_name'] ?? $user['name'], 0, 1)) ?>
            </div>
            
            <h2 style="margin-bottom: 0.5rem;"><?= htmlspecialchars($user['name']) ?></h2>
            <small style="color: var(--text-muted); font-family: monospace; display: block; margin-bottom: 1.5rem;"><?= $qr ?></small>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; max-width: 600px; margin: 0 auto; text-align: left; background: var(--bg-main); padding: 1.5rem; border-radius: var(--radius-md);">
                <div class="info-group">
                    <span class="info-label">Course</span>
                    <div class="info-value"><?= htmlspecialchars($user['course'] ?? '-') ?></div>
                </div>
                <div class="info-group">
                    <span class="info-label">Birthday</span>
                    <?php if (!empty($user['birthday'])): ?>
                        <div class="info-value"><?= date('F j, Y', strtotime($user['birthday'])) ?></div>
                    <?php else: ?>
                        <div class="info-placeholder">Not set</div>
                    <?php endif; ?>
                </div>
                
                <div class="info-group">
                    <span class="info-label">Contact Number</span>
                    <div class="info-value"><?= htmlspecialchars($user['contact_number'] ?? '-') ?></div>
                </div>
                <div class="info-group">
                    <span class="info-label">Email Address</span>
                    <div class="info-value"><?= htmlspecialchars($user['email'] ?? '-') ?></div>
                </div>
                
                <div class="info-group">
                    <span class="info-label">Sex</span>
                    <div class="info-value"><?= htmlspecialchars($user['sex'] ?? '-') ?></div>
                </div>
                <div class="info-group">
                    <span class="info-label">Civil Status</span>
                    <div class="info-value"><?= htmlspecialchars($user['civil_status'] ?? '-') ?></div>
                </div>
                
                <div class="info-group">
                    <span class="info-label">Place of Birth</span>
                    <div class="info-value"><?= htmlspecialchars($user['place_of_birth'] ?? '-') ?></div>
                </div>
                <div class="info-group">
                    <span class="info-label">Religion</span>
                    <div class="info-value"><?= htmlspecialchars($user['religion'] ?? '-') ?></div>
                </div>
                
                 <div class="info-group">
                    <span class="info-label">Citizenship</span>
                    <div class="info-value"><?= htmlspecialchars($user['citizenship'] ?? '-') ?></div>
                </div>
            </div>
            
            <div style="margin-top: 1.5rem;">
                <span class="badge" style="background: #ecfdf5; color: #047857; border: 1px solid #a7f3d0; padding: 0.5rem 1rem; font-size: 0.9rem;">
                    Attendance Rate: <?= $rate ?>%
                </span>
            </div>
        </div>

        <!-- Stats Grid -->
        <div class="animate-fade-up delay-1" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; margin-bottom: 2rem;">
            <div class="stat-card">
                <div class="stat-val" style="color: var(--success);"><?= $present ?></div>
                <div class="stat-label">Present</div>
            </div>
            <div class="stat-card">
                <div class="stat-val" style="color: var(--warning);"><?= $late ?></div>
                <div class="stat-label">Late</div>
            </div>
            <div class="stat-card">
                <div class="stat-val" style="color: var(--danger);"><?= $absent ?></div>
                <div class="stat-label">Absent</div>
            </div>
        </div>

        <!-- History -->
        <h4 style="margin-bottom: 1rem;">Recent Activity</h4>
        <div class="card animate-fade-up delay-2" style="overflow: hidden;">
            <?php if (empty($history)): ?>
                <div style="padding: 2rem; text-align: center; color: var(--text-muted);">No records found.</div>
            <?php else: ?>
                <?php foreach ($history as $h): ?>
                    <div class="history-item">
                        <div>
                            <div style="font-weight: 500;"><?= date('F j, Y', strtotime($h['date'])) ?></div>
                            <small style="color: var(--text-muted);">
                                <?= $h['status'] === 'absent' ? '--' : date('h:i A', strtotime($h['time'])) ?>
                            </small>
                        </div>
                        <span class="badge badge-<?= $h['status'] ?>" style="
                            <?php 
                                if($h['status']=='present') echo 'background:#dcfce7; color:#166534;'; 
                                elseif($h['status']=='late') echo 'background:#ffedd5; color:#d97706;'; 
                                else echo 'background:#fee2e2; color:#dc2626;'; 
                            ?>
                        "><?= ucfirst($h['status']) ?></span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Recent Subject Attendance -->
        <h4 style="margin-bottom: 1rem; margin-top: 2rem;">Recent Class Attendance</h4>
        <div class="card animate-fade-up delay-3" style="overflow: hidden;">
            <?php 
            $stmtSub = $pdo->prepare("
                SELECT sa.*, s.name as subject_name, s.id as subject_id 
                FROM subject_attendance sa 
                JOIN subjects s ON sa.subject_id = s.id 
                WHERE sa.qr_code = ? 
                ORDER BY sa.date DESC, sa.time DESC 
                LIMIT 10
            ");
            $stmtSub->execute([$qr]);
            $subHistory = $stmtSub->fetchAll(PDO::FETCH_ASSOC);
            ?>
            <?php if (empty($subHistory)): ?>
                <div style="padding: 2rem; text-align: center; color: var(--text-muted);">No class records found.</div>
            <?php else: ?>
                <?php foreach ($subHistory as $h): ?>
                    <div class="history-item">
                        <div>
                             <div style="font-weight: 500;">
                                <a href="view_subject_attendance.php?id=<?= $h['subject_id'] ?>" style="color:var(--text-main); text-decoration:none;" onmouseover="this.style.color='var(--primary)'" onmouseout="this.style.color='var(--text-main)'">
                                    <?= htmlspecialchars($h['subject_name']) ?>
                                </a>
                            </div>
                            <small style="color: var(--text-muted);">
                                <?= !empty($h['date']) ? date('F j, Y', strtotime($h['date'])) : '--' ?> • 
                                <?= !empty($h['time']) ? date('h:i A', strtotime($h['time'])) : '--' ?>
                            </small>
                        </div>
                        <span class="badge badge-<?= $h['status'] ?>" style="
                            <?php 
                                if($h['status']=='present') echo 'background:#dcfce7; color:#166534;'; 
                                elseif($h['status']=='late') echo 'background:#ffedd5; color:#d97706;'; 
                                else echo 'background:#fee2e2; color:#dc2626;'; 
                            ?>
                        "><?= ucfirst($h['status']) ?></span>
                    </div>
                <?php endforeach; ?>
                 <div style="padding: 0.5rem; text-align: center; background: #f8fafc; border-top: 1px solid var(--border);">
                    <a href="student_history.php?qr_code=<?= urlencode($qr) ?>" style="font-size: 0.85rem; color: var(--primary); text-decoration: none; font-weight: 600;">View Full History <i class="bi bi-arrow-right"></i></a>
                </div>
            <?php endif; ?>
        </div>

    </main>

    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <form method="POST" class="modal-content animate-fade-up">
            <input type="hidden" name="action" value="update_profile">
            <div style="display: flex; justify-content: space-between; margin-bottom: 1.5rem;">
                <h3>Edit Profile</h3>
                <button type="button" onclick="closeEditModal()" style="background:none; border:none; font-size: 1.2rem;"><i class="bi bi-x-lg"></i></button>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">First Name *</label>
                    <input type="text" name="first_name" class="form-control" value="<?= htmlspecialchars($user['first_name'] ?? '') ?>" required>
                </div>
                <div style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Last Name *</label>
                    <input type="text" name="last_name" class="form-control" value="<?= htmlspecialchars($user['last_name'] ?? '') ?>" required>
                </div>
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Middle Initial</label>
                <input type="text" name="middle_initial" class="form-control" value="<?= htmlspecialchars($user['middle_initial'] ?? '') ?>" maxlength="5">
            </div>

            <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Course</label>
                <input type="text" name="course" class="form-control" value="<?= htmlspecialchars($user['course'] ?? '') ?>">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                 <div style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Birthday</label>
                    <input type="date" name="birthday" class="form-control" value="<?= $user['birthday'] ?? '' ?>">
                </div>
                 <div style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Sex</label>
                    <select name="sex" class="form-control">
                        <option value="">Select...</option>
                        <option value="Male" <?= ($user['sex']??'') === 'Male' ? 'selected' : '' ?>>Male</option>
                        <option value="Female" <?= ($user['sex']??'') === 'Female' ? 'selected' : '' ?>>Female</option>
                    </select>
                </div>
            </div>


            <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Contact Number</label>
                <input type="text" name="contact_number" class="form-control" value="<?= htmlspecialchars($user['contact_number'] ?? '') ?>">
            </div>
             <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Email Address</label>
                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email'] ?? '') ?>">
            </div>
            
             <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                 <div style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Civil Status</label>
                    <select name="civil_status" class="form-control">
                        <option value="">Select...</option>
                        <option value="Single" <?= ($user['civil_status']??'') === 'Single' ? 'selected' : '' ?>>Single</option>
                        <option value="Married" <?= ($user['civil_status']??'') === 'Married' ? 'selected' : '' ?>>Married</option>
                        <option value="Widowed" <?= ($user['civil_status']??'') === 'Widowed' ? 'selected' : '' ?>>Widowed</option>
                    </select>
                </div>
                 <div style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Citizenship</label>
                     <input type="text" name="citizenship" class="form-control" value="<?= htmlspecialchars($user['citizenship'] ?? '') ?>">
                </div>
            </div>
            
             <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Religion</label>
                <input type="text" name="religion" class="form-control" value="<?= htmlspecialchars($user['religion'] ?? '') ?>">
            </div>
            
            <div style="margin-bottom: 1.5rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Place of Birth</label>
                <input type="text" name="place_of_birth" class="form-control" value="<?= htmlspecialchars($user['place_of_birth'] ?? '') ?>">
            </div>


            <div style="text-align: right;">
                <button type="button" onclick="closeEditModal()" class="btn btn-ghost" style="margin-right: 0.5rem;">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </form>
    </div>

    <script>
        function openEditModal() {
            document.getElementById('editModal').style.display = 'flex';
        }
        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }
        
        // Close on outside click
        window.onclick = function(event) {
            if (event.target == document.getElementById('editModal')) {
                closeEditModal();
            }
        }

        <?php if (isset($_GET['msg']) && $_GET['msg'] == 'saved'): ?>
            Swal.fire({
                icon: 'success',
                title: 'Profile Updated',
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 2000
            });
            // Clear URL param
            window.history.replaceState({}, document.title, window.location.pathname + window.location.search.replace(/[\?&]msg=saved/, ''));
        <?php endif; ?>
    </script>
</body>
</html>
