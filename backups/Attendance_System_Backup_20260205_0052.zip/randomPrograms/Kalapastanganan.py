import sys
from time import sleep
import time

def print_lyrics():
    lines = [
        ("Mamamatay akong nakangiti", 0.12),
        ("Kapag Ikaw ang nasa aking tabi", 0.12),
        ("Mabubuhay akong nagsisisi", 0.15),
        ("Kapag ′sang araw hindi kita mapapangiti", 0.11),
        ("Kalapastangan ang 'di Ka ibigin", 0.12),
        ("Kalokohan ang ′di Ka isipin", 0.12),
        ("Kung ang mundo ay biglang gugunawin", 0.12),
        ("Ikaw ang una kong hahanapin", 0.12),
    ]

    delays = [0.7,0.6 ,0.7 ,0.6 ,0.6, 0.6, 0.5, 0.5,1]

    for i, (line, char_delay) in enumerate(lines):
        for char in line:
            print(char, end='')
            sys.stdout.flush()
            sleep(char_delay)
        time.sleep(delays[i])
        print('')

print_lyrics()