print("Calculator!")
print("Basic operations: +, -, *, /")

num1 = int(input("Enter first number: "))
ope = input("Enter operator: ")
num2 = int(input("Enter second number: "))

Result = None

if ope == "+":
    Result = num1 + num2
elif ope == "-":
    Result = num1 - num2
elif ope == "*":
    Result = num1 * num2
elif ope == "/":
    
    if num2 != 0:
        Result = num1 / num2
    else:
        print("Error: Division by zero!")
else:
    print("Invalid operator!")

if Result is not None:
    print(f"{num1} {ope} {num2} = {Result}")