import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class kalapastanganan extends JPanel {
    private List<LyricLine> lyrics;
    private int currentLine = 0;
    private int currentChar = 0;
    private Timer charTimer;
    private Timer lineTimer;
    private JLabel lyricLabel;
    
    public kalapastanganan() {
        setBackground(Color.BLACK);
        setLayout(new GridBagLayout());
        
    
        lyrics = new ArrayList<>();
        lyrics.add(new LyricLine("Mamamatay akong nakangiti", 120, 700));
        lyrics.add(new LyricLine("Kapag Ikaw ang nasa aking tabi", 120, 600));
        lyrics.add(new LyricLine("Mabubuhay akong nagsisisi", 150, 700));
        lyrics.add(new LyricLine("Kapag ′sang araw hindi kita mapapangiti", 110, 600));
        lyrics.add(new LyricLine("Kalapastangan ang 'di Ka ibigin", 120, 600));
        lyrics.add(new LyricLine("Kalokohan ang ′di Ka isipin", 120, 600));
        lyrics.add(new LyricLine("Kung ang mundo ay biglang gugunawin", 120, 500));
        lyrics.add(new LyricLine("Ikaw ang una kong hahanapin", 120, 500));
        
       
        lyricLabel = new JLabel();
        lyricLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        lyricLabel.setForeground(Color.WHITE);
        add(lyricLabel);
        
  
        charTimer = new Timer(lyrics.get(currentLine).charDelay, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentChar < lyrics.get(currentLine).text.length()) {
                    String displayedText = "<html><b>" + lyrics.get(currentLine).text.substring(0, currentChar + 1) + "</b></html>";
                    lyricLabel.setText(displayedText);
                    currentChar++;
                } else {
                    charTimer.stop();
                    // Start line timer to wait before next line
                    lineTimer.setInitialDelay(lyrics.get(currentLine).lineDelay);
                    lineTimer.start();
                }
            }
        });
        
        // Timer for delay between lines
        lineTimer = new Timer(0, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lineTimer.stop();
                currentLine++;
                if (currentLine < lyrics.size()) {
                    currentChar = 0;
                    lyricLabel.setText("");
                    fadeInLabel();
                    charTimer.setDelay(lyrics.get(currentLine).charDelay);
                    charTimer.start();
                }
            }
        });
        
        // Start the animation
        fadeInLabel();
        charTimer.start();
    }
    
    private void fadeInLabel() {
        lyricLabel.setForeground(new Color(255, 255, 255, 0));
        Timer fadeTimer = new Timer(30, null);
        fadeTimer.addActionListener(new ActionListener() {
            float alpha = 0;
            @Override
            public void actionPerformed(ActionEvent e) {
                alpha += 0.05f;
                if (alpha >= 1) {
                    alpha = 1;
                    fadeTimer.stop();
                }
                lyricLabel.setForeground(new Color(255, 255, 255, (int)(alpha * 255)));
            }
        });
        fadeTimer.start();
    }
    
    private class LyricLine {
        String text;
        int charDelay; // milliseconds per character
        int lineDelay; // milliseconds after line completes
        
        public LyricLine(String text, int charDelay, int lineDelay) {
            this.text = text;
            this.charDelay = charDelay;
            this.lineDelay = lineDelay;
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame("Made by MCK");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setSize(550, 200);
                frame.setLocationRelativeTo(null);
                
                kalapastanganan player = new kalapastanganan();
                frame.add(player);
                
                frame.setVisible(true);
            }
        });
    }
}