<?php
// scan.php - Simple Student QR Scanner (Modal Version)
date_default_timezone_set('Asia/Manila');
require_once 'includes/db.php';

// Get settings
$stmt = $pdo->query("SELECT * FROM settings LIMIT 1");
$settings = $stmt->fetch(PDO::FETCH_ASSOC);
$callTime = $settings['call_time'] ?? '08:00';

// Fetch Today's Attendance for List
$todayParams = date('Y-m-d');
$sql = "SELECT 
            u.name, 
            a.time, 
            a.status 
        FROM attendance a 
        LEFT JOIN users u ON a.qr_code = u.qr_code 
        WHERE a.date = :date 
        ORDER BY a.time DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([':date' => $todayParams]);
$todaysRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalToday = count($todaysRecords);

// Fetch Subjects
$stmt = $pdo->query("SELECT id, name, semester FROM subjects ORDER BY semester DESC, name ASC");
$subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
$groupedSubjects = [];
foreach ($subjects as $s) {
    $groupedSubjects[$s['semester']][] = $s;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scanner | QR Tools by MCK</title>
    <link href="assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/vendor/bootstrap-icons/bootstrap-icons.css">
    <script src="assets/js/html5-qrcode.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* Modal Styles matching Billing */
        #scannerModal {
            position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.8);
            z-index: 1000;
            display: none;
            align-items: center;
            justify-content: center;
        }
        .scanner-content {
            background: white;
            width: 95%; max-width: 400px;
            padding: 1rem;
            border-radius: var(--radius-lg);
            position: relative;
        }

        /* Mobile Adjustments */
        @media (max-width: 400px) {
            .scanner-content {
                padding: 0.75rem;
                width: 98%;
            }
            #reader {
                min-height: 250px;
            }
        }
        
        /* List Styles */
        .attendance-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 1rem;
            border-bottom: 1px solid var(--border);
            background: white;
        }
        .attendance-row:first-child { border-top-left-radius: var(--radius-lg); border-top-right-radius: var(--radius-lg); }
        .attendance-row:last-child { border-bottom: none; border-bottom-left-radius: var(--radius-lg); border-bottom-right-radius: var(--radius-lg); }
        
        /* Status Badges */
        .badge-present { color: #166534; background: #dcfce7; }
        .badge-late { color: #d97706; background: #ffedd5; }
        .badge-absent { color: #dc2626; background: #fee2e2; }
    </style>
</head>
<body>

    <!-- Nav -->
    <?php 
    $show_clock = true;
    include 'includes/navbar.php'; 
    ?>

    <main class="container" style="padding-top: 2rem;">
        
        <!-- Main Actions -->
        <div style="text-align: center; margin-bottom: 2rem;" class="animate-fade-up">
            <h1 style="margin-bottom: 1rem;">Attendance Scanner</h1>
            <p style="color: var(--text-muted); margin-bottom: 1.5rem;">
                Scan QR codes to mark attendance.
            </p>
            <button onclick="toggleScanner()" class="btn btn-primary" style="padding: 1rem 3rem; font-size: 1.2rem; border-radius: 50px; box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);">
                <i class="bi bi-qr-code-scan"></i> Scan Now
            </button>
            <div style="margin-bottom: 1rem;">
                <label for="scanSubject" style="font-weight: bold; margin-bottom: 0.5rem; display: block; color: var(--text-muted);">Subject Mode (Optional)</label>
                <select id="scanSubject" class="form-control" style="width: 100%; max-width: 300px; margin: 0 auto;">
                    <option value="">-- Daily Attendance (Default) --</option>
                    <?php foreach ($groupedSubjects as $sem => $subs): ?>
                        <optgroup label="<?= htmlspecialchars($sem) ?>">
                            <?php foreach ($subs as $s): ?>
                                <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?></option>
                            <?php endforeach; ?>
                        </optgroup>
                    <?php endforeach; ?>
                </select>
                <small style="display: block; margin-top: 0.5rem; color: var(--text-muted);">Select a subject to log attendance for that class specifically.</small>
            </div>


        </div>

        <!-- Recent Scans List -->
        <div class="animate-fade-up delay-1">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <h4 style="color: var(--text-main);">
                    Recent Scans 
                    <span id="subjectIndicator" style="font-size: 0.8em; color: var(--text-muted); font-weight: normal;">(Daily)</span>
                </h4>
                <div style="text-align:right;">
                     <span id="countBadge" style="background:#e0e7ff; color:#4338ca; padding:2px 8px; border-radius:12px; font-size:0.85rem; font-weight:bold;">0</span>
                     <a href="view_attendance.php" style="color: var(--primary); text-decoration: none; font-size: 0.9rem; margin-left:10px;">View Full</a>
                </div>
            </div>

            <div id="recentList" style="box-shadow: var(--shadow-sm); border-radius: var(--radius-lg); border: 1px solid var(--border); min-height: 100px; background: white;">
                <!-- Content injected via JS -->
                <div style="padding: 2rem; text-align: center;">
                    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Loading...
                </div>
            </div>
        </div>

    </main>

    <!-- Scanner Modal -->
    <div id="scannerModal">
        <div class="scanner-content animate-fade-up">
            <div style="display: flex; justify-content: space-between; margin-bottom: 1rem;">
                <h4>Scan QR</h4>
                <button onclick="toggleScanner()" style="background:none; border:none; font-size: 1.2rem;"><i class="bi bi-x-lg"></i></button>
            </div>
            
            <div style="position: relative;">
                <div id="reader" style="width: 100%; border-radius: var(--radius-md); overflow: hidden;"></div>
            </div>

            <p style="text-align: center; margin-top: 1rem; color: var(--text-muted); font-size: 0.9rem;">
                Point camera at student QR code.
            </p>
        </div>
    </div>

    <!-- Audio -->
    <audio id="successSound" src="assets/audio/game-bonus-2-294436.mp3"></audio>
    <audio id="warningSound" src="assets/audio/reject-interface-sound.mp3"></audio>
    <audio id="errorSound" src="assets/audio/bad-machine.mp3"></audio>

    <script>
        // Clock
        setInterval(() => {
            let el = document.getElementById('clock');
            if(el) el.innerText = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
        }, 1000);

        // Scanner Logic
        let html5QrCode = null;
        let lastScanned = "";
        let isProcessing = false;
        
        const sounds = {
            success: document.getElementById('successSound'),
            warning: document.getElementById('warningSound'),
            error: document.getElementById('errorSound')
        };

        function playSound(type) {
            try { sounds[type].currentTime = 0; sounds[type].play(); } catch(e) {}
        }

        async function toggleScanner() {
            const modal = document.getElementById('scannerModal');
            
            if (modal.style.display === 'flex') {
                // Close Scanner
                modal.style.display = 'none';
                if (html5QrCode) {
                    try {
                        if(html5QrCode.isScanning) {
                            await html5QrCode.stop();
                        }
                        await html5QrCode.clear();
                    } catch (error) {
                        console.error("Failed to stop scanner", error);
                    }
                    html5QrCode = null;
                }
            } else {
                // Open Scanner
                modal.style.display = 'flex';
                // Small delay to ensure modal is rendered
                setTimeout(startScanning, 300);
            }
        }

        function startScanning() {
             if (html5QrCode) {
                 // Already initialized
                 return;
             }

             // Initialize the scanner
             html5QrCode = new Html5Qrcode("reader");

             const config = { 
                 fps: 10, 
                 qrbox: { width: 250, height: 250 },
                 aspectRatio: 1.0 
             };

             // Try environment camera first (back camera), fallback to user (front/webcam)
             // Ideally 'facingMode: "environment"' works, but on desktop it might fail.
             // We can use the generic { facingMode: "environment" } which usually falls back, 
             // but explicit handling is safer.
             
             html5QrCode.start(
                 { facingMode: "environment" }, 
                 config, 
                 processScan, 
                 (errorMessage) => { 
                     // frame error, ignore 
                 }
             ).catch(err => {
                 console.warn("Environment camera failed, trying user camera...", err);
                 // Fallback to user camera (webcam)
                 html5QrCode.start(
                     { facingMode: "user" }, 
                     config, 
                     processScan, 
                     (errorMessage) => { /* ignore */ }
                 ).catch(err2 => {
                     // Both failed
                     handleCameraError(err2);
                 });
             });
        }

        // Removed initScannerUI as we use start() directly now
        function handleCameraError(e) {
            console.error(e);
            let msg = "Scanner Error: " + (e.message || e);
            
            // Friendly Error Messages
            if (e.name === 'NotAllowedError' || (e.message && e.message.includes('permission'))) {
                    msg = "Camera Access Denied.<br><br>The browser blocked the camera. If you are on Windows/Android, ensure you are using <b>HTTPS</b> or <b>localhost</b>.";
            } else if (e.name === 'NotFoundError') {
                    msg = "No camera found on this device.";
            } else if (e.name === 'NotReadableError') {
                    msg = "Camera is being used by another application.";
            } else if (e.message && e.message.indexOf("The request is not not allowed") > -1) {
                    msg = "Permission denied. Check browser settings.";
            }
            
            Swal.fire({
                title: 'Camera Error',
                html: msg,
                icon: 'error',
                footer: '<a href="manual.php" class="btn btn-sm btn-secondary">Go to Manual Entry</a>',
                showConfirmButton: true
            });
        }

        function processScan(qrCode) {
            if (qrCode === lastScanned || isProcessing) return;
            
            lastScanned = qrCode;
            isProcessing = true;
            
            console.log("Scanned:", qrCode);

            // Pause scanning while processing
            // if(html5QrcodeScanner) html5QrcodeScanner.pause(); // Not strictly necessary if we use isProcessing flag

            const subjectId = document.getElementById('scanSubject').value;

            fetch('api/process.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ 
                    qr_code: qrCode,
                    subject_id: subjectId
                })
            })
            .then(r => r.json())
            .then(data => {
                if (data.status === 'new') {
                    // New Registration
                    Swal.fire({
                        title: 'New Student',
                        html: `
                            <p style="margin-bottom:15px; color:#666;">Unknown QR. Register new student?</p>
                            <input id="reg-firstname" class="swal2-input" placeholder="First Name" style="margin-bottom: 10px;">
                            <input id="reg-lastname" class="swal2-input" placeholder="Last Name">
                        `,
                        showCancelButton: true,
                        confirmButtonText: 'Register',
                        preConfirm: () => {
                            const fname = document.getElementById('reg-firstname').value.trim();
                            const lname = document.getElementById('reg-lastname').value.trim();
                            if(!fname || !lname) {
                                Swal.showValidationMessage('First and Last Name required');
                            }
                            return { first_name: fname, last_name: lname };
                        }
                    }).then((result) => {
                        if (result.isConfirmed && result.value) {
                            fetch('api/process.php', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                body: new URLSearchParams({ 
                                    qr_code: qrCode, 
                                    first_name: result.value.first_name, 
                                    last_name: result.value.last_name 
                                })
                            }).then(r => r.json()).then(regHelper);
                        } else {
                            resumeScanning();
                        }
                    });
                } else if (data.status === 'duplicate') {
                    playSound('warning');
                    shortToast('info', `${data.user_name} already scanned.`);
                    // resumeScanning(); // Let finally handle delay
                } else if (data.status === 'success') {
                    playSound('success');
                    shortToast('success', `Marked ${data.attendance_status.toUpperCase()}: ${data.user_name}`);
                    fetchRecentList(); // Update List Immediately
                    // resumeScanning(); // Let finally handle delay
                } else {
                    playSound('error');
                    shortToast('error', data.message);
                    // resumeScanning(); // Let finally handle delay
                }
            })
            .catch((err) => {
                console.error(err);
                shortToast('error', 'Database Error');
                // resumeScanning(); // Let finally handle delay
            })
            .finally(() => {
                // Reset scan lock after delay
                setTimeout(() => { 
                    lastScanned = ""; 
                    isProcessing = false; 
                }, 3000);
            });
        }

        function resumeScanning() {
             if(html5QrCode) {
                 isProcessing = false;
                 // Allow re-scanning same code if needed? 
                 lastScanned = ""; 
             }
        }
        
        function regHelper(data) {
             if(data.status === 'success') {
                playSound('success');
                Swal.fire('Registered!', 'Student added.', 'success').then(() => {
                    fetchRecentList(); // Refresh list
                    resumeScanning();
                });
            } else {
                Swal.fire('Error', data.message, 'error').then(() => {
                    resumeScanning();
                });
            }
        }

        function shortToast(icon, title) {
            Swal.fire({
                icon: icon,
                title: title,
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 2000
            });
        }

        // --- Real-time List Logic ---
        
        function fetchRecentList() {
            const subjectId = document.getElementById('scanSubject').value;
            const indicator = document.getElementById('subjectIndicator');
            
            // Update UI Title
            if (subjectId) {
                const sel = document.getElementById('scanSubject');
                const text = sel.options[sel.selectedIndex].text;
                indicator.innerText = `(${text})`;
                indicator.style.color = 'var(--primary)';
                indicator.style.fontWeight = 'bold';
            } else {
                indicator.innerText = '(Daily)';
                indicator.style.color = 'var(--text-muted)';
                indicator.style.fontWeight = 'normal';
            }

            fetch(`api/get_recent.php?subject_id=${subjectId}`)
                .then(r => r.json())
                .then(res => {
                    if (res.status === 'success') {
                        renderList(res.data);
                    }
                })
                .catch(e => console.error(e));
        }

        function renderList(data) {
            const container = document.getElementById('recentList');
            const countBadge = document.getElementById('countBadge');
            
            countBadge.innerText = data.length;

            if (data.length === 0) {
                container.innerHTML = `
                    <div style="padding: 2rem; text-align: center;">
                        <p style="color: var(--text-muted);">No scans yet for this mode.</p>
                    </div>`;
                return;
            }

            let html = '';
            data.forEach(row => {
                const statusClass = 'badge-' + (row.status || 'present').toLowerCase();
                html += `
                    <div class="attendance-row animate-fade-up">
                        <div>
                            <div style="font-weight: 600; font-size: 1rem;">${escapeHtml(row.name)}</div>
                            <small style="color: var(--text-muted);"><i class="bi bi-clock"></i> ${row.time}</small>
                        </div>
                        <span class="badge ${statusClass}">${(row.status || 'PRESENT').toUpperCase()}</span>
                    </div>
                `;
            });
            container.innerHTML = html;
        }

        function escapeHtml(text) {
            if (!text) return text;
            return text
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");
        }

        // Check for updates every 5 seconds
        setInterval(fetchRecentList, 5000);

        // Subject Change Listener
        document.getElementById('scanSubject').addEventListener('change', () => {
             fetchRecentList();
        });
        
        // Auto-select subject on load
        window.addEventListener('load', () => {
             fetch('api/subject_process.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: new URLSearchParams({ action: 'get_current_subject' })
            })
            .then(r => r.json())
            .then(d => {
                if(d.status === 'success') {
                     const sel = document.getElementById('scanSubject');
                     if(sel) {
                         sel.value = d.data.id;
                         shortToast('info', `Auto-selected: ${d.data.name}`);
                     }
                }
                // Fetch list initially (after auto-select check logic or default)
                // We add a small delay or just call it.
                // Parameter override check takes precedence
                checkUrlParam();
            })
            .catch(() => {
                // Determine list anyway if fetch fails
                checkUrlParam();
            });
        });

        function checkUrlParam() {
             const urlParams = new URLSearchParams(window.location.search);
             const urlSubId = urlParams.get('subject_id');
             if(urlSubId) {
                 const sel = document.getElementById('scanSubject');
                 if(sel) {
                     sel.value = urlSubId;
                     toggleScanner();
                 }
             }
             // Initial Fetch
             fetchRecentList();
        }
        
    </script>
</body>
</html>
