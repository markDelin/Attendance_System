<?php
// seed_today_v2.php
date_default_timezone_set('Asia/Manila');
require_once 'includes/db.php';

try {
    // 1. Get 10 random students
    $stmt = $pdo->query("SELECT qr_code, name FROM users LIMIT 10");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($users)) {
        die("Error: No users found in database. Please register students first.");
    }

    $today = date('Y-m-d');
    $statuses = ['present', 'present', 'present', 'late', 'late', 'present']; 

    echo "Adding records for today ($today)...<br>";

    // Clean up first
    $pdo->exec("DELETE FROM attendance WHERE date = '$today'");

    $count = 0;
    foreach ($users as $u) {
        $status = $statuses[array_rand($statuses)];
        $hour = rand(7, 9);
        $min = rand(0, 59);
        $time = sprintf("%02d:%02d", $hour, $min);
        $session = ($hour < 12) ? 'morning' : 'afternoon';

        $sql = "INSERT INTO attendance (qr_code, date, time, status, session) VALUES (?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $res = $stmt->execute([$u['qr_code'], $today, $time, $status, $session]);
        
        if($res) {
            echo "Marked {$u['name']} as $status at $time<br>";
            $count++;
        } else {
             echo "Failed for {$u['name']}<br>";
        }
    }

    echo "<br><b>Success! Added $count records.</b>";

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
