<?php
require 'includes/db.php';

$columns = $pdo->query("PRAGMA table_info(users)")->fetchAll(PDO::FETCH_ASSOC);
$colNames = array_column($columns, 'name');

$expected = [
    'first_name', 'last_name', 'middle_initial', 'course', 
    'place_of_birth', 'sex', 'civil_status', 'religion', 
    'citizenship', 'contact_number', 'birthday'
];

$missing = [];
foreach ($expected as $exp) {
    if (!in_array($exp, $colNames)) {
        $missing[] = $exp;
    }
}

if (empty($missing)) {
    echo "SUCCESS: All columns are present.\n";
    foreach ($colNames as $col) {
        if (in_array($col, $expected)) {
            echo " - $col (Found)\n";
        }
    }
} else {
    echo "ERROR: Missing columns: " . implode(', ', $missing) . "\n";
}
?>
