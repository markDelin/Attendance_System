<?php
// view_subject_attendance.php - View Specific Subject History
date_default_timezone_set("Asia/Manila");
require_once "includes/db.php";

$subjectId = $_GET['id'] ?? 0;
if (!$subjectId) { header("Location: view_subjects_list.php"); exit; }

// Get Subject Details
$stmt = $pdo->prepare("SELECT * FROM subjects WHERE id = ?");
$stmt->execute([$subjectId]);
$subject = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$subject) die("Subject not found");

// Fetch Dates for this Subject
$stmt = $pdo->prepare("SELECT DISTINCT date FROM subject_attendance WHERE subject_id = ? ORDER BY date DESC");
$stmt->execute([$subjectId]);
$dates = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($subject['name']) ?> | Records</title>
    <link href="assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/vendor/bootstrap-icons/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .table-wrapper {
            background: white;
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        table { width: 100%; border-collapse: collapse; }
        th { 
            text-align: left; padding: 1.25rem; 
            background: #f8fafc; color: var(--text-muted); 
            font-size: 0.85rem; text-transform: uppercase;
            border-bottom: 1px solid var(--border);
        }
        td { padding: 1.25rem; border-bottom: 1px solid var(--border); }
        tr:last-child td { border-bottom: none; }
        
        .section-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 1rem; margin-top: 3rem;
        }
        
        /* Status Badges */
        .badge-present { color: #166534; background: #dcfce7; }
        .badge-late { color: #d97706; background: #ffedd5; }
        .badge-absent { color: #dc2626; background: #fee2e2; }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="view_subjects_list.php" class="btn btn-ghost" style="border: none; padding-left: 0;">
            <i class="bi bi-arrow-left"></i> <span class="d-none-mobile">Subjects List</span>
        </a>
        <h3 class="text-gradient"><?= htmlspecialchars($subject['name']) ?></h3>
        <button onclick="exportSubjectRange()" class="btn btn-ghost">
            <i class="bi bi-file-earmark-spreadsheet"></i> <span class="d-none-mobile">Export Matrix</span>
        </button>
    </nav>

    <main class="container">
        <!-- Header Info -->
        <div class="animate-fade-up">
             <div style="background: var(--surface); padding: 1.5rem; border-radius: var(--radius-lg); border: 1px solid var(--border); margin-bottom: 2rem;">
                 <h2 style="margin: 0;"><?= htmlspecialchars($subject['name']) ?></h2>
                 <p style="color: var(--text-muted); margin-top: 0.5rem;">
                     <?= htmlspecialchars($subject['semester']) ?> <span style="margin: 0 10px;">•</span> <?= count($dates) ?> Class Days Recorded
                 </p>
             </div>
        </div>

        <?php if (empty($dates)): ?>
            <div class="card animate-fade-up" style="padding: 4rem; text-align: center; margin-top: 2rem;">
                <i class="bi bi-calendar-x" style="font-size: 3rem; color: var(--text-muted); display: block; margin-bottom: 1rem;"></i>
                <h4 style="color: var(--text-muted);">No attendance records found for this subject.</h4>
            </div>
        <?php else: ?>

            <?php foreach ($dates as $index => $row): ?>
                <div class="animate-fade-up delay-<?= min($index + 1, 3) ?>">
                    
                    <div class="section-header">
                        <div class="flex-center" style="gap: 1rem;">
                            <h4 style="margin: 0; color: var(--text-main);"><?= date('F j, Y', strtotime($row['date'])) ?></h4>
                            <span class="badge" style="background: white; border: 1px solid var(--border);">
                                <?php
                                $count = $pdo->query("SELECT COUNT(*) FROM subject_attendance WHERE subject_id = $subjectId AND date = '{$row['date']}'")->fetchColumn();
                                echo "$count Entries";
                                ?>
                            </span>
                        </div>
                        
                        <div style="display: flex; gap: 0.5rem;">
                            <!-- Single Day Export -->
                            <button onclick="exportSubjectDay('<?= $row['date'] ?>')" class="btn btn-ghost" style="font-size: 0.85rem; padding: 0.5rem 1rem;">
                                    <i class="bi bi-download"></i> Export Day
                            </button>
                            
                            <!-- Delete Day (Warning: Only deletes this subject's records for this day) -->
                            <!-- We need a specific delete API for subject attendance or modify delete.php -->
                            <button onclick="deleteDay('<?= $row['date'] ?>')" 
                                    class="btn btn-ghost" style="color: var(--danger); font-size: 0.85rem; padding: 0.5rem 1rem;">
                                <i class="bi bi-trash"></i> Clear
                            </button>
                        </div>
                    </div>

                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th>Student Name</th>
                                    <th>Status</th>
                                    <th>Time Logged</th>
                                    <th style="text-align: right;"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT sa.id, sa.status, sa.time, sa.qr_code, u.name 
                                        FROM subject_attendance sa 
                                        JOIN users u ON sa.qr_code = u.qr_code 
                                        WHERE sa.subject_id = ? AND sa.date = ? 
                                        ORDER BY sa.id DESC";
                                $stmtRec = $pdo->prepare($sql);
                                $stmtRec->execute([$subjectId, $row['date']]);
                                $records = $stmtRec->fetchAll(PDO::FETCH_ASSOC);

                                foreach ($records as $r): 
                                    $statusClass = 'badge-' . strtolower($r['status']);
                                    // Use 'time' column which holds local time string
                                    $time = $r['time'] ? date('h:i A', strtotime($r['time'])) : '--';
                                ?>
                                <tr>
                                    <td style="font-weight: 500;">
                                        <a href="profile.php?qr=<?= urlencode($r['qr_code']) ?>" style="color: var(--text-main); text-decoration: none;" onmouseover="this.style.color='var(--primary)'" onmouseout="this.style.color='var(--text-main)'">
                                            <?= htmlspecialchars($r['name']) ?>
                                        </a>
                                    </td>
                                    <td>
                                        <span class="badge" style="background:var(--bg-subtle); border:1px solid var(--border); padding: 4px 8px; border-radius: 4px; font-weight: 600; text-transform: uppercase; font-size: 0.75rem; color: var(--text-main); "><?= ucfirst($r['status']) ?></span>
                                    </td>
                                    <td style="color: var(--text-muted); font-family: monospace;"><?= $time ?></td>
                                    <td style="text-align: right;">
                                        <button onclick="deleteRecord(<?= $r['id'] ?>)" style="background: none; border: none; cursor: pointer; color: var(--text-muted);">
                                            <i class="bi bi-x-lg"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </main>

    <script>
        function exportSubjectRange() {
            Swal.fire({
                title: 'Export Subject Matrix',
                html: `
                    <div style="text-align:left">
                        <p style="font-size:0.9rem; color:#666; margin-bottom:1rem;">Select date range for aggregated export.</p>
                        <div style="display:flex; gap:10px; margin-bottom:15px;">
                            <div style="flex:1">
                                <label style="font-size:0.85rem; font-weight:600;">Start</label>
                                <input type="date" id="swal-start" class="swal2-input" value="<?= date('Y-m-d') ?>" style="margin:0; width:100%">
                            </div>
                            <div style="flex:1">
                                <label style="font-size:0.85rem; font-weight:600;">End</label>
                                <input type="date" id="swal-end" class="swal2-input" value="<?= date('Y-m-d') ?>" style="margin:0; width:100%">
                            </div>
                        </div>
                        
                        <label style="display:block; margin-bottom:5px; font-weight:600; color:var(--text-main)">Format</label>
                        <div style="display:flex; gap:15px;">
                            <label style="display:flex; align-items:center; cursor:pointer;">
                                <input type="radio" name="swal-format" value="xls" checked style="margin-right:8px;"> 
                                <span>Excel (.xls)</span>
                            </label>
                            <label style="display:flex; align-items:center; cursor:pointer;">
                                <input type="radio" name="swal-format" value="html" style="margin-right:8px;"> 
                                <span>Google Sheets (.html)</span>
                            </label>
                        </div>
                    </div>
                `,
                showCancelButton: true,
                confirmButtonText: 'Download',
                preConfirm: () => {
                    return [
                        document.getElementById('swal-start').value,
                        document.getElementById('swal-end').value,
                        document.querySelector('input[name="swal-format"]:checked').value
                    ]
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    const [start, end, format] = result.value;
                    const url = `api/export_subject.php?subject_id=<?= $subjectId ?>&start=${start}&end=${end}&format=${format}`;
                    window.open(url, '_blank');
                }
            })
        }

        function exportSubjectDay(date) {
             Swal.fire({
                title: 'Export Day',
                html: `
                    <div style="text-align:left">
                        <p style="margin-bottom:15px">Exporting records for <b>${date}</b></p>
                        <label style="display:block; margin-bottom:5px; font-weight:600; color:var(--text-main)">Format</label>
                        <div style="display:flex; gap:15px;">
                            <label style="display:flex; align-items:center; cursor:pointer;">
                                <input type="radio" name="swal-format" value="xls" checked style="margin-right:8px;"> 
                                <span>Excel (.xls)</span>
                            </label>
                            <label style="display:flex; align-items:center; cursor:pointer;">
                                <input type="radio" name="swal-format" value="html" style="margin-right:8px;"> 
                                <span>Google Sheets (.html)</span>
                            </label>
                        </div>
                    </div>
                `,
                showCancelButton: true,
                confirmButtonText: 'Download',
                preConfirm: () => {
                   return document.querySelector('input[name="swal-format"]:checked').value
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    const format = result.value;
                    const url = `api/export_subject.php?subject_id=<?= $subjectId ?>&start=${date}&end=${date}&format=${format}`;
                    window.open(url, '_blank');
                }
            })
        }
        
        // We need a delete handler for subject attendance specifically
        // I should probably update api/delete.php or create api/delete_subject_record.php
        // For now, let's assume we'll create a new handler in next step.

        function deleteRecord(id) {
             Swal.fire({
                title: 'Delete Record?',
                text: "This student's attendance for this class will be removed.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                confirmButtonText: 'Yes, delete'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Call API
                    const formData = new FormData();
                    formData.append('type', 'subject_record');
                    formData.append('id', id);
                    
                    fetch('api/delete_subject.php', { method: 'POST', body: formData })
                        .then(r => r.json())
                        .then(d => {
                            if(d.status === 'success') location.reload();
                            else Swal.fire('Error', d.message, 'error');
                        });
                }
            })
        }

        function deleteDay(date) {
            Swal.fire({
                title: 'Clear Day?',
                text: `Clear all records for this subject on ${date}?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                confirmButtonText: 'Yes, clear date'
            }).then((result) => {
                if (result.isConfirmed) {
                    const formData = new FormData();
                    formData.append('type', 'subject_day');
                    formData.append('subject_id', <?= $subjectId ?>);
                    formData.append('date', date);
                    
                    fetch('api/delete_subject.php', { method: 'POST', body: formData })
                        .then(r => r.json())
                        .then(d => {
                            if(d.status === 'success') location.reload();
                            else Swal.fire('Error', d.message, 'error');
                        });
                }
            })
        }
    </script>
</body>
</html>
