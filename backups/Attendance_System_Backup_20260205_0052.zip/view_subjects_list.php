<?php
// view_subjects_list.php - List of Subjects to View Attendance
date_default_timezone_set("Asia/Manila");
require_once "includes/db.php";

// Fetch Subjects
$stmt = $pdo->query("SELECT * FROM subjects ORDER BY semester DESC, name ASC");
$subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);

$grouped = [];
foreach ($subjects as $s) {
    $grouped[$s['semester']][] = $s;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subject Records | Attendance System</title>
    <link href="assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/vendor/bootstrap-icons/bootstrap-icons.css">
    <style>
        .subject-card {
            background: white;
            padding: 1.5rem;
            border-radius: var(--radius-lg);
            border: 1px solid var(--border);
            box-shadow: var(--shadow-sm);
            transition: transform 0.2s, box-shadow 0.2s;
            cursor: pointer;
            text-decoration: none;
            color: inherit;
            display: block;
        }
        .subject-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            border-color: var(--primary);
        }
        .subjects-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .sem-title {
            color: var(--text-muted);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 1rem;
            border-bottom: 1px solid var(--border);
            padding-bottom: 0.5rem;
        }
        .view-toggle {
            display: inline-flex; background: #f1f5f9; padding: 4px; border-radius: 12px;
            margin-bottom: 2rem; border: 1px solid var(--border);
        }
        .toggle-btn {
            padding: 8px 20px; border-radius: 8px; text-decoration: none; color: var(--text-muted);
            font-weight: 600; font-size: 0.9rem; transition: all 0.2s; border: none; background: none; cursor: pointer;
        }
        .toggle-btn.active {
            background: white; color: var(--primary); box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        }
        .toggle-btn:hover:not(.active) { color: var(--text-main); background: #e2e8f0; }
    </style>
</head>
<body>

    <?php include 'includes/navbar.php'; ?>

    <main class="container">
        
        <!-- View Toggle -->
        <div class="animate-fade-up">
            <div class="view-toggle">
                <a href="view_attendance.php" class="toggle-btn">📅 Daily Records</a>
                <a href="view_subjects_list.php" class="toggle-btn active">📚 Subject Records</a>
            </div>
            
            <h1 style="margin-bottom: 0.5rem;">Select Subject</h1>
            <p style="color: var(--text-muted); margin-bottom: 2rem;">
                View detailed attendance logs for a specific subject.
            </p>
        </div>

        <?php if (empty($grouped)): ?>
            <div class="card animate-fade-up" style="padding: 4rem; text-align: center;">
                <i class="bi bi-journal-x" style="font-size: 3rem; color: var(--text-muted); display: block; margin-bottom: 1rem;"></i>
                <h4 style="color: var(--text-muted);">No subjects found</h4>
                <a href="groups.php" class="btn btn-primary" style="margin-top: 1rem;">Manage Subjects</a>
            </div>
        <?php else: ?>
            <?php foreach ($grouped as $sem => $subs): ?>
                <div class="animate-fade-up">
                    <h5 class="sem-title"><?= htmlspecialchars($sem) ?></h5>
                    <div class="subjects-grid">
                        <?php foreach ($subs as $s): 
                            // Get stats
                            $count = $pdo->query("SELECT COUNT(*) FROM subject_attendance WHERE subject_id = {$s['id']}")->fetchColumn();
                        ?>
                        <a href="view_subject_attendance.php?id=<?= $s['id'] ?>" class="subject-card">
                            <div style="display: flex; justify-content: space-between; align-items: start;">
                                <div>
                                    <h3 style="margin: 0; font-size: 1.2rem; color: var(--text-main);"><?= htmlspecialchars($s['name']) ?></h3>
                                    <span style="font-size: 0.9rem; color: var(--text-muted); display: block; margin-top: 0.25rem;">
                                        ID: <?= $s['id'] ?>
                                    </span>
                                </div>
                                <span class="badge" style="background: var(--bg-subtle); color: var(--primary);">
                                    <?= $count ?> Records
                                </span>
                            </div>
                            <div style="margin-top: 1rem; text-align: right; font-size: 0.9rem; color: var(--primary);">
                                View History <i class="bi bi-arrow-right"></i>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

    </main>
</body>
</html>
